# Advanced Healthcare Data Engineering

A base end-to-end data engineering project for healthcare data.

## Architecture
```
Source (synthetic EHR) -> RAW (csv) -> CLEAN (validated + de-identified) -> WAREHOUSE (SQLite star schema) -> REPORTS
```

## Features
- **Extract**: synthetic patients, encounters and lab results (with deliberate dirty data)
- **Transform**: deduplication, gender standardization, age groups, BMI, length of stay, lab flags (LOW/NORMAL/HIGH)
- **Privacy**: names/phones/DOB dropped, patient IDs pseudonymized (salted SHA-256)
- **Data quality**: 8 automated checks; bad rows quarantined; pipeline aborts if checks fail
- **Load**: star schema (`dim_patient`, `dim_date`, `fact_encounter`, `fact_lab`)
- **Analytics**: monthly cost/volume, readmission by diagnosis, cost by demographics, abnormal lab rates, high utilizers

## Run
```bash
pip install -r requirements.txt
python pipeline.py
```
Outputs: `data/raw`, `data/clean`, `data/warehouse.db`, `reports/*.csv`

## Next steps
Swap SQLite for PostgreSQL/Snowflake, orchestrate with Airflow, ingest real HL7/FHIR data, add dbt models, add pytest + CI, store secrets in a vault.

> Uses synthetic data only. Real PHI requires HIPAA/DPDP-compliant handling.
